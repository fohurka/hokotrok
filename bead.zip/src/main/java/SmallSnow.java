public class SmallSnow extends Surface {

    public SmallSnow(Lane lane)
    {
        super(lane);
    }

    public SmallSnow(Lane lane, Modifier mod) {
        super(lane, mod);
    }

    @Override
    public void addSnow(int amount) {
        snowAmount += amount;
        if (snowAmount > snowThreshold) {
            Surface newSurf = new DeepSnow(lane, modifier);
            newSurf.addSnow(snowAmount);
            newSurf.addIce(iceAmount);
            lane.setSurface(newSurf);
        }
    }

    @Override
    public void addIce(int amount) {
        iceAmount += amount;
        if (iceAmount > iceThreshold) {
            Surface newSurf = new Ice(lane, modifier);
            newSurf.addIce(iceAmount);
            lane.setSurface(newSurf);
        }
    }

    @Override
    public int removeSnow() {
        int amount = snowAmount;
        snowAmount = 0;
        return amount;
    }

    @Override
    public int removeSnow(int amount) {
        if (amount > snowAmount) {
            amount = snowAmount;
        }
        snowAmount -= amount;
        return amount;
    }

    @Override
    public int removeIce() {
        int amount = iceAmount;
        iceAmount = 0;
        return amount;
    }

    @Override
    public int removeIce(int amount) {
        if (amount > iceAmount) {
            amount = iceAmount;
        }
        iceAmount -= amount;
        return amount;
    }

    /**
     * Calculates the progress of a CivilVehicle
     * @param cv the CivilVehicle that progresses
     * @return the amount of progress the CivilVehicle made
     */
    @Override
    public int calculateProgress(CivilVehicle cv) {
        return 1;
    }

    /**
     * @return whether the surface makes the Lane enterable
     */
    @Override
    public boolean enterable() {
        return true;
    }

    
    /**
     * Applies its Modifier and tries to set the new surface to DeepSnow
     */
    @Override
    public void tick() {
        modifier.applyWeather(this);
    }

    /**
     * Tries to add ice and tries to set the new surface to Ice
     */
    @Override
    protected void carPassed() {
        if (snowAmount > 0)
            addIce(1);
    }
}
